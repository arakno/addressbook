##Betitt code test

#Run:

$ bower install

$ npm install

#Start server:

 npm start
 
#Navigate to localhost:3000